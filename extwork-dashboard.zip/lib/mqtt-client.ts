/**
 * 데모 목적의 간단한 MQTT 클라이언트
 * 실제 애플리케이션에서는 MQTT.js와 같은 라이브러리를 사용해야 합니다
 */
export default class MqttClient {
  private connected = false
  private topics: string[] = []
  private simulationMode = true

  // 콜백
  public onConnect: () => void = () => {}
  public onDisconnect: () => void = () => {}
  public onMessage: (topic: string, message: string) => void = () => {}

  constructor() {
    // 실제 애플리케이션에서는 여기서 MQTT 클라이언트를 초기화합니다
    console.log("MQTT 클라이언트가 시뮬레이션 모드로 초기화되었습니다")
  }

  /**
   * MQTT 브로커에 연결
   */
  connect(): void {
    if (this.simulationMode) {
      console.log("MQTT 연결 시뮬레이션 중...")
      setTimeout(() => {
        this.connected = true
        console.log("시뮬레이션된 MQTT 연결이 설정되었습니다")
        this.onConnect()
      }, 1000)
    } else {
      // 실제 MQTT 연결 로직이 여기에 들어갑니다
    }
  }

  /**
   * MQTT 브로커에서 연결 해제
   */
  disconnect(): void {
    if (this.simulationMode) {
      console.log("MQTT 연결 해제 시뮬레이션 중...")
      setTimeout(() => {
        this.connected = false
        console.log("시뮬레이션된 MQTT 연결 해제가 완료되었습니다")
        this.onDisconnect()
      }, 500)
    } else {
      // 실제 MQTT 연결 해제 로직이 여기에 들어갑니다
    }
  }

  /**
   * 토픽 구독
   */
  subscribe(topic: string): void {
    if (!this.topics.includes(topic)) {
      this.topics.push(topic)
      console.log(`토픽 구독: ${topic}`)
    }
  }

  /**
   * 토픽 구독 해제
   */
  unsubscribe(topic: string): void {
    this.topics = this.topics.filter((t) => t !== topic)
    console.log(`토픽 구독 해제: ${topic}`)
  }

  /**
   * 토픽에 메시지 발행
   */
  publish(topic: string, message: string): void {
    if (this.simulationMode) {
      console.log(`${topic}에 발행: ${message}`)

      // 이 토픽을 구독하고 있다면 메시지 수신 시뮬레이션
      if (this.topics.includes(topic)) {
        setTimeout(() => {
          this.onMessage(topic, message)
        }, 200)
      }
    } else {
      // 실제 MQTT 발행 로직이 여기에 들어갑니다
    }
  }

  /**
   * MQTT 브로커에 연결되어 있는지 확인
   */
  isConnected(): boolean {
    return this.connected
  }
}

